<?php
echo"<html>
<head>
     <title>STUDNET PAGE</title>
</head>
<body align='center' style='background-image:linear-gradient(to right,rgba(28, 182, 67, 0.473),rgba(0, 255, 21, 0.74));'>
    <h3 align='center'>WELCOME</h3><ul align='right'>
    <ul align='left' style='text-decoration: none;list-style:none;color: brown;font-weight: 900;'>   
        <a href='updatedetails.php' style='text-decoration: none;'><img src='image/forward.png' alt='UPDATE STUDENT DETAILS' title='UPDATE STUDENT DETAILS' style='width: 50px;height: 50px;'>
        <b>UPDATE STUDENT DETAILS</b></a>
        <a href='sroomdetails.php' style='text-decoration: none;' ><img src='image/door.png' alt='ROOM DETAILS' title='ROOM DETAILS' style='width: 50px;height: 50px;margin-left: 60px'><b>ROOM DETAILS</b></a>
        <a href='index.php' style='text-decoration: none;'><img src='image/exit.png' alt='LOGOUT' title='LOGOUT' style='width: 50px;height: 50px; padding-right:0px;margin-left: 525px'><b>LOG OUT</b></a> 
        </ul>
   </body>
   ";

   echo"<br><br><br><br><footer align='center'>&copy; All Rights Reserved,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<a href='#' align='right' title='CONTACT US' style='text-decoration: none;'><img src='image/contact.png' alt='CONTACT US' style='width: 50px;height: 50px;'>
</a></footer>";

?>