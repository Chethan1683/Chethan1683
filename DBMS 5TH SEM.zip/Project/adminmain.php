<?php
echo"<html lang='en'>
<hea>
    <title>HOSTEL ADMIN</title>
</head>
<body style='background-image:linear-gradient(to right,rgba(28, 182, 67, 0.473),rgba(0, 255, 21, 0.74));'>
<h3 align='center'    style='font-size: xx-large;
font-family: system-ui;
font-weight: 900;'>ADMIN MAIN</h3>
<h4 align='center' style='font-family:-webkit-body;
font-weight: 900;'>WELCOME</h4>
    <div>
    <ul align='left' style='text-decoration: none;color: red;font-weight: 900;'>
        <a href='studentdetails.php' style='text-decoration: none;'>
        <img src='image/profile.png' alt='STUDENT DETAILS' title='STUDENT DETAILS' style='width: 50px;height: 50px;text-decoration: none;margin-right: 00px;'>STUDENT DETAILS</a>
        <a href='empdetails.php' style='text-decoration: none;'>
        <img src='image/school-bag.png' alt='EMPLYOEE DETAILS' title='EMPLYOEE DETAILS' style='width: 50px;height: 50px;text-decoration: none;margin-left: 25px;margin-right: 00px;'>EMPLOYEE DETAILS</a>
        <a href='roomdetails.php' style='text-decoration: none;' ><img src='image/door.png' alt='ROOM DETAILS' title='ROOM DETAILS' style='width: 50px;height: 50px;margin-left:25px'><b>ROOM DETAILS</b></a>
        <a href='fee.php' style='text-decoration: none;'>
        <img src='image/bill.png' alt='FEE DETAILS' title='FEE DETAILS' style='width: 50px;height: 50px;text-decoration: none;margin-left: 30px;margin-right: 40px;text-decoration: none;margin-left: 25px;margin-right: 00px;'>FEE DETAILS</a>
        <a href='INDEX.php' style='text-decoration: none;'><img src='image/left-arrow.png' alt='BACK' title='BACK' style='width: 50px;height: 50px;margin-left:100px;'><b>BACK</b></a>
        <a href='index.php'  style='text-decoration: none;'>
        <img src='image/exit.png' alt='LOG OUT' title='LOG OUT' style='width: 50px;height: 50px;text-decoration: none;margin-left: 50px;'>LOG OUT</a>
    </ul>
    </div>
    <div>
    <footer align='center' style='padding-top: 200px'>
    &copy; All Rights Reserved,&nbsp;&nbsp; <a href='#' title='CONTACT US' style='text-decoration: none;'>
    <img src='image/contact.png' alt='CONTACT US' style='width: 50px;height: 50px;'></a>
    </footer>
    </div>
</body>
</html>";
?>
